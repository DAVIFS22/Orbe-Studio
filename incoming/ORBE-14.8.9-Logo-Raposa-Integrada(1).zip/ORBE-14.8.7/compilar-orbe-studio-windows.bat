@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo   ORBE STUDIO 14.8.2 - compilacao nativa
echo ==============================================
where cargo >nul 2>nul
if errorlevel 1 (
  echo ERRO: Rust/Cargo nao encontrado.
  echo Instale Rust 1.95 ou superior em https://rustup.rs/
  echo No Windows, instale tambem o Visual Studio Build Tools com C++ Desktop.
  pause
  exit /b 1
)
if not exist Cargo.toml (
  echo ERRO: Cargo.toml nao encontrado. Extraia o ZIP completo antes de compilar.
  pause
  exit /b 1
)
if not exist apps\orbe-studio\Cargo.toml (
  echo ERRO: arquivo principal do Orbe Studio nao encontrado em apps\orbe-studio\Cargo.toml.
  echo Extraia novamente o ZIP completo para uma pasta local.
  pause
  exit /b 1
)
if not exist apps\orbe-studio\src\main.rs (
  echo ERRO: codigo-fonte principal do Orbe Studio esta incompleto.
  pause
  exit /b 1
)
echo Compilando o editor nativo egui/eframe e todos os crates do workspace...
cargo build --release -p orbe --bin orbe-studio
if errorlevel 1 (
  echo.
  echo A compilacao falhou. Veja o primeiro erro do Cargo acima.
  pause
  exit /b 1
)
echo.
echo Compilacao concluida: target\release\orbe-studio.exe
pause
