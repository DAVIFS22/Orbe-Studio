# Licenses

ORBE source is dual-licensed under MIT or Apache-2.0 at the user's option. The authoritative terms are the repository files:

- [`LICENSE-MIT`](https://github.com/storytold/orbe/blob/main/LICENSE-MIT)
- [`LICENSE-APACHE`](https://github.com/storytold/orbe/blob/main/LICENSE-APACHE)
- [`NOTICE`](https://github.com/storytold/orbe/blob/main/NOTICE)
- [`ATTRIBUTION.md`](https://github.com/storytold/orbe/blob/main/ATTRIBUTION.md)

Bundled third-party assets retain their own licenses and attribution requirements. The ORBE name, wordmark, and logos in `docs/brand/` are subject to [`docs/brand/LICENSE-brand.txt`](https://github.com/storytold/orbe/blob/main/docs/brand/LICENSE-brand.txt) and are not covered by the source-code license.

This page summarizes repository locations and does not alter any ownership or license term.
