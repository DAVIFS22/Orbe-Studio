# Orbe Imagem Studio 14.7.0 — refinamento do editor

- Refinamento visual da interface escura, ferramentas, estados de foco e contraste.
- Clique vazio com a ferramenta Texto não cria mais um objeto automaticamente.
- Criação de texto passa a ser explícita pelo botão Novo texto; clique no canvas seleciona texto existente ou informa que não há texto naquele ponto.
- Preservadas as ferramentas e rotinas existentes do projeto.

## Escopo
Esta versão é uma primeira etapa de melhoria da experiência do editor, não uma implementação integral de todos os recursos do Adobe Photoshop. Recursos devem ser validados individualmente.
